import { DataCPaging as PaginationSystem } from './dataCPaging';
import '../css/pagination.css';
export default PaginationSystem;
